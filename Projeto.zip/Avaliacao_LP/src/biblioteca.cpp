/*
 * File: biblioteca.cpp
 *  Created on: 15 de maio de 2018
 *      Author: LUCAS
 */

#include <iostream>
using namespace std;
#include "../include/biblioteca.hpp"

Biblioteca::Biblioteca() { // @suppress("Class members should be properly initialized")
	this->quantidadeCDs = 0;
	this->quantidadeDVDs = 0;
	this->quantidadeLivros = 0;
}

Biblioteca::~Biblioteca() {

}

int Biblioteca::getQuantidadeLivros() {
	return this->quantidadeLivros;
}

void Biblioteca::setQuantidadeLivros(int umaQuantidade) {
	this->quantidadeLivros = umaQuantidade;
}

int Biblioteca::getQuantidadeCDs() {
	return this->quantidadeCDs;
}

void Biblioteca::setQuantidadeCDs(int umaQuantidade) {
	this->quantidadeCDs = umaQuantidade;
}

int Biblioteca::getQuantidadeDVDs() {
	return this->quantidadeDVDs;
}

void Biblioteca::setQuantidadeDVDs(int umaQuantidade) {
	this->quantidadeDVDs = umaQuantidade;
}

void Biblioteca::inserirMidia() {
	cout << "|---------------Inser��o de M�dia-----------------|\n" << endl;
	cout << "Informe o n�mero referente ao tipo de m�dia que deseja inserir"
			<< endl << "0. Livro;" << endl << "1. CD;" << endl
			<< "2. DVD;" << endl << "Digite aqui: ";
	int tipoMidia;
	cin >> tipoMidia;
	if (tipoMidia == 0) {
		cin.ignore();
		int anoLivro;
		string tituloLivro, autor, editora, isbn;
		cout << "Informe o t�tulo do livro: " << endl;
		getline(cin, tituloLivro);
		cout << "Informe o autor do livro: " << endl;
		getline(cin, autor);
		cout << "Informe o editora do livro: " << endl;
		getline(cin, editora);
		cout << "Informe o isbn do livro: " << endl;
		getline(cin, isbn);
		cout << "Informe o ano de lan�amento do livro: " << endl;
		cin >> anoLivro;

		Livro * livro = new Livro;
		livro->setTitulo(tituloLivro);
		livro->setAutor(autor);
		livro->setEditora(editora);
		livro->setAno_Lancamento(anoLivro);
		livro->setISBN(isbn);
		livro->setTipoDeMidia(0);

		Midia* midiaLivro = livro;
		for (int i = 0; i < (int) this->midias.size(); i++) {
			if (this->midias[i]->getTitulo() == midiaLivro->getTitulo()
					&& this->midias[i]->getTipoDeMidia()
							== midiaLivro->getTipoDeMidia()) {
				cout << "ERRO! A biblioteca j� possui essa midia!" << endl;
				cout << "________________________________________" << endl;
				return;
			}
		}
		this->midias.push_back(midiaLivro);
		this->quantidadeLivros++;

		cout << "Livro inserido com sucesso!" << endl;
	}

	else if (tipoMidia == 1) {
		cin.ignore();
		int anoCD, quantidadeFaixas;
		string tituloCD, compositor, gravadora;
		cout << "Informe o nome do �lbum: " << endl;
		getline(cin, tituloCD);
		cout << "Informe o artista/banda do �lbum: " << endl;
		getline(cin, compositor);
		cout << "Informe a gravadora do �lbum: " << endl;
		getline(cin, gravadora);
		cout << "Informe a quantidade de faixas do �lbum: " << endl;
		cin >> quantidadeFaixas;
		cout << "Informe o ano de lan�amento do �lbum: " << endl;
		cin >> anoCD;

		CD * cd = new CD;
		cd->setTitulo(tituloCD);
		cd->setAutor(compositor);
		cd->setGravadora(gravadora);
		cd->setAno_Lancamento(anoCD);
		cd->setQuantidadeFaixas(quantidadeFaixas);
		cd->setTipoDeMidia(1);
		Midia* midiaCD = cd;

		for (int i = 0; i < (int) this->midias.size(); i++) {
			if (this->midias[i]->getTitulo() == midiaCD->getTitulo()
					&& this->midias[i]->getTipoDeMidia()
							== midiaCD->getTipoDeMidia()) {
				cout << "ERROR! A biblioteca j� possui essa midia!";
				return;
			}
		}
		this->midias.push_back(midiaCD);
		this->quantidadeCDs++;

		cout << "CD inserido com sucesso!" << endl;

	} else if (tipoMidia == 2) {
		cin.ignore();
		int anoDVD, duracao;
		string tituloDVD, diretor, classificacao;
		cout << "Informe o nome do filme: " << endl;
		getline(cin, tituloDVD);
		cout << "Informe o diretor do filme: " << endl;
		getline(cin, diretor);
		cout << "Informe a classifica��o indicativa do filme: " << endl;
		getline(cin, classificacao);
		cout << "Informe a dura��o do filme (em minutos): " << endl;
		cin >> duracao;
		cout << "Informe o ano de lan�amento do filme: " << endl;
		cin >> anoDVD;

		DVD * dvd = new DVD;
		dvd->setTitulo(tituloDVD);
		dvd->setAutor(diretor);
		dvd->setDuracao(duracao);
		dvd->setAno_Lancamento(anoDVD);
		dvd->setClassificacao(classificacao);
		dvd->setTipoDeMidia(2);

		Midia* midiaDVD = dvd;

		for (int i = 0; i < (int) this->midias.size(); i++) {
			if (this->midias[i]->getTitulo() == midiaDVD->getTitulo()
					&& this->midias[i]->getTipoDeMidia()
							== midiaDVD->getTipoDeMidia()) {
				cout << "ERROR! A biblioteca j� possui essa midia!";
				cout << "_______________________________________" << endl;
				return;
			}
		}
		this->midias.push_back(midiaDVD);
		this->quantidadeDVDs++;

		cout << "DVD inserido com sucesso!" << endl;

	} else {
		cout << "ERROR! Tipo de m�dia desconhecido!" << endl;
	}

	cout << "_______________________________________" << endl;

}

Midia* Biblioteca::buscarMidia(string umNome, int umTipoDeMidia) {
	for (int i = 0; i < (int) this->midias.size(); i++) {
		if (this->midias[i]->getTitulo() == umNome
				&& this->midias[i]->getTipoDeMidia() == umTipoDeMidia) {
			return this->midias[i];
		}
	}

	return NULL;
}

void Biblioteca::removerMidia() {
	cin.ignore();
	int tipoMidia;
	string nome;
	cout <<"|--------------Remo��o de M�dia---------------|" << endl;
	cout << "Informe o nome da m�dia que deseja remover: " << endl;
	getline(cin, nome);
	cout << "Informe o tipo de m�dia que deseja remover: " << endl;
	cin >> tipoMidia;
	Midia* midiaPraDeletar = this->buscarMidia(nome, tipoMidia);
	if (!midiaPraDeletar) {
		cout << "ERROR! M�dia inexistente." << endl;
		cout <<"_______________________________________" << endl;
		return;
	}
	for (int i = 0; i < (int) this->midias.size(); i++) {
		if (this->midias[i]->getTitulo() == midiaPraDeletar->getTitulo()
				&& this->midias[i]->getTipoDeMidia()
						== midiaPraDeletar->getTipoDeMidia()) {
			if (midiaPraDeletar->getTipoDeMidia() == 0) {
				this->quantidadeLivros--;
			} else if (midiaPraDeletar->getTipoDeMidia() == 1) {
				this->quantidadeCDs--;
			} else if (midiaPraDeletar->getTipoDeMidia() == 2) {
				this->quantidadeDVDs--;
			}
			this->midias.erase(midias.begin() + i);
			break;
		}
	}

	cout << "M�dia removida da biblioteca com sucesso!" << endl;
	cout <<"_______________________________________" << endl;

}

void Biblioteca::detalharMidia(Midia* umaMidia) {
	if (umaMidia->getTipoDeMidia() == 0) {
		Livro* aux = (Livro*) umaMidia;
		cout << "------------Livro--------------" << endl << "T�tulo: "
				<< aux->getTitulo() << ";" << endl << "Autor: "
				<< aux->getAutor() << ";" << endl << "Ano de Lan�amento: "
				<< aux->getAno_Lancamento() << ";" << endl << "Editora: "
				<< aux->getEditora() << ";" << endl << "ISBN: "
				<< aux->getISBN() << "." << endl
				<< "______________________________" << endl;

	} else if (umaMidia->getTipoDeMidia() == 1) {
		CD* aux = (CD*) umaMidia;
		cout << "-------------CD---------------" << endl << "T�tulo: "
				<< aux->getTitulo() << ";" << endl << "Banda/Artista: "
				<< aux->getAutor() << ";" << endl << "Ano de Lan�amento: "
				<< aux->getAno_Lancamento() << ";" << endl << "Gravadora: "
				<< aux->getGravadora() << ";" << endl << "N�mero de Faixas: "
				<< aux->getQuantidadeFaixas() << "." << endl
				<< "_____________________________" << endl;
	} else if (umaMidia->getTipoDeMidia() == 2) {
		DVD* aux = (DVD*) umaMidia;
		cout << "-------------DVD---------------" << endl << "T�tulo: "
				<< aux->getTitulo() << ";" << endl << "Diretor: "
				<< aux->getAutor() << ";" << endl << "Ano de Lan�amento: "
				<< aux->getAno_Lancamento() << ";" << endl
				<< "Classifica��o Indicativa: " << aux->getClassificacao()
				<< ";" << endl << "Dura��o: " << aux->getDuracao()
				<< " minutos." << endl << "____________________________"
				<< endl;
	}
}

void Biblioteca::editarMidia() {
	cin.ignore();
	int tipoMidia;
	string nome;
	cout << "|--------------Edi��o de M�dia--------------|"  << endl;
	cout << "Informe o nome da m�dia que deseja editar: " << endl;
	getline(cin, nome);
	cout << "Informe o tipo de m�dia que deseja editar: " << endl;
	cin >> tipoMidia;

	Midia* midiaPraEditar = this->buscarMidia(nome, tipoMidia);
	if (midiaPraEditar) {
		cin.ignore();
		cout << "O estado atual desta m�dia �:" << endl;
		this->detalharMidia(midiaPraEditar);
		if (midiaPraEditar->getTipoDeMidia() == 0) {
			Livro* livroEditado = (Livro*) midiaPraEditar;

			cout << "Informe o novo t�tulo:" << endl;
			string novoTitulo;
			getline(cin, novoTitulo);
			livroEditado->setTitulo(novoTitulo);

			cout << "Informe o novo autor:" << endl;
			string novoAutor;
			getline(cin, novoAutor);
			livroEditado->setAutor(novoAutor);

			cout << "Informe a nova editora:" << endl;
			string novaEditora;
			getline(cin, novaEditora);
			livroEditado->setEditora(novaEditora);
			cout << "Informe o novo IBSN:" << endl;

			string novoibsn;
			getline(cin, novoibsn);
			livroEditado->setISBN(novoibsn);

			cout << "Informe o novo ano de lan�amento:" << endl;
			int novoAno;
			cin >> novoAno;
			livroEditado->setAno_Lancamento(novoAno);

		} else if (midiaPraEditar->getTipoDeMidia() == 1) {
			CD* cdEditado = (CD*) midiaPraEditar;

			cout << "Informe o novo t�tulo:" << endl;
			string novoTitulo;
			getline(cin, novoTitulo);
			cdEditado->setTitulo(novoTitulo);

			cout << "Informe o novo banda/artista:" << endl;
			string novoAutor;
			getline(cin, novoAutor);
			cdEditado->setAutor(novoAutor);

			cout << "Informe a nova gravadora:" << endl;
			string novaGravadora;
			getline(cin, novaGravadora);
			cdEditado->setGravadora(novaGravadora);

			cout << "Informe a nova quantidade de faixas:" << endl;
			int faixas;
			cin >> faixas;
			cdEditado->setQuantidadeFaixas(faixas);

			cout << "Informe o novo ano de lan�amento:" << endl;
			int novoAno;
			cin >> novoAno;
			cdEditado->setAno_Lancamento(novoAno);

		} else if (midiaPraEditar->getTipoDeMidia() == 2) {
			DVD* dvdEditado = (DVD*) midiaPraEditar;

			cout << "Informe o novo t�tulo:" << endl;
			string novoTitulo;
			getline(cin, novoTitulo);
			dvdEditado->setTitulo(novoTitulo);

			cout << "Informe o novo diretor:" << endl;
			string novoAutor;
			getline(cin, novoAutor);
			dvdEditado->setAutor(novoAutor);

			cout << "Informe a nova classifica��o et�ria:" << endl;
			string novaClassificacao;
			getline(cin, novaClassificacao);
			dvdEditado->setClassificacao(novaClassificacao);

			cout << "Informe o novo ano de lan�amento:" << endl;
			int novoAno;
			cin >> novoAno;
			dvdEditado->setAno_Lancamento(novoAno);

			cout << "Informe a nova dura��o:" << endl;
			int novaDuracao;
			cin >> novaDuracao;
			dvdEditado->setDuracao(novaDuracao);

		}

		cout << "M�dia editada com sucesso!" << endl;
	} else {
		cout << "ERROR! M�dia informada inexistente!" << endl;
	}

	cout << "_______________________________________________" << endl;
}

void Biblioteca::verAcervo() {
	cout <<"|--------------Acervo da Biblioteca--------------|" << endl;
	for (int i = 0; i < (int) this->midias.size(); i++) {
		this->detalharMidia(this->midias[i]);
	}
	cout << "________________________________________________" << endl;
}

void Biblioteca::verEstatisticas() {
	cout << "------------------- Estat�sticas da Biblioteca -------------------"
			<< endl;
	cout << "Existem: " << this->quantidadeLivros << " livros em nosso acervo;"
			<< endl;
	cout << "Existem: " << this->quantidadeCDs << " CD's em nosso acervo;"
			<< endl;
	cout << "Existem: " << this->quantidadeDVDs << " DVD's em nosso acervo."
			<< endl;
	cout << "__________________________________________________________________"<< endl;
}
